const platforms = ['PC', 'Nintendo', 'PS4', 'PS5', 'XBOX'];

module.exports = { platforms };